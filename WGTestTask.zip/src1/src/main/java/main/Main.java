package main;

import dbcontroller.DatabaseController;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) throws Exception {
        DatabaseController dbController = new DatabaseController();
        double tailMean =0;
        double tailMedian = 0;
        ArrayList<Integer> tailMode;

        double whiskersMean = 0;
        double whiskersMedian = 0;
        ArrayList<Integer> whiskersMode;

        /*
          Task 1:
          calculates and fills the cat_colors_info table
         */
        dbController.clearTable("cat_colors_info");
        dbController.processAndFillCatColorsInfo();


        dbController.clearTable("cats_stat");
        tailMean = dbController.calculateMeanValue("tail_length");
        whiskersMean = dbController.calculateMeanValue("whiskers_length");

        tailMedian = dbController.calculateMedian("tail_length");
        whiskersMedian = dbController.calculateMedian("whiskers_length");

        tailMode = dbController.calculateMode("tail_length");
        whiskersMode = dbController.calculateMode("whiskers_length");
        dbController.insertStatsToDB(tailMean,tailMedian,tailMode,whiskersMean,whiskersMedian,whiskersMode);
    }
}
