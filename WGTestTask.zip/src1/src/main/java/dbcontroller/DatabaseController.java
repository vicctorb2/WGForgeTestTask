package dbcontroller;

import java.sql.*;
import java.text.DecimalFormat;
import java.util.*;

public class DatabaseController {

    //connection configuration params
    private String url = "jdbc:postgresql://127.0.0.1:5432/wg_forge_db";
    private String username = "wg_forge";
    private String pass = "a42";


    private static Connection connection;

    //constructor trying to find jdbc class for postgresql and then establish a connection
    public DatabaseController() {
        try {
            Class.forName("org.postgresql.Driver");
            connection = DriverManager.getConnection(url, username, pass);
        } catch (ClassNotFoundException e) {
            System.out.println("Driver cannot be found");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Something went wrong while establishing a connection...");
            e.printStackTrace();
        }
    }

    /*
     * This method fills the cat_colors_info table with the info of how many cats of each color exists in the cats table
     */

    public void processAndFillCatColorsInfo() {
        ArrayList<String> colorTypes = getAllColorTypes(); //trying t get unique cat_color types
        if (colorTypes != null) {
            try {

                //a statement that returns count of cats with the color, specified by param
                PreparedStatement colorCountCalculationStatement = connection.prepareStatement("SELECT COUNT(*) FROM cats WHERE color = ?::cat_color");

                for (String type : colorTypes) {
                    colorCountCalculationStatement.setString(1, type); //each type goes to prepared statement as param
                    ResultSet resultSet = colorCountCalculationStatement.executeQuery();
                    while (resultSet.next()) {
                        int countOfCatsWithThisColor = resultSet.getInt(1);
                        PreparedStatement insertCountDataStmt = connection.prepareStatement("INSERT INTO cat_colors_info(color,count) VALUES (?::cat_color,?)"); //this stmt inserts calculated data to cat_color_info table
                        insertCountDataStmt.setString(1, type);
                        insertCountDataStmt.setInt(2, countOfCatsWithThisColor);
                        insertCountDataStmt.executeUpdate();
                        insertCountDataStmt.close();
                    }
                }
                colorCountCalculationStatement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("There is no color types were created for this database");
        }
    }



    /*This method returns the list of all available cat_color type values in db*/
    private ArrayList<String> getAllColorTypes() {
        ArrayList<String> allColorTypesList = new ArrayList<String>();
        try {
            Statement getColorTypesStmt = null;
            getColorTypesStmt = connection.createStatement();
            ResultSet resultSet = getColorTypesStmt.executeQuery(
                    " SELECT pg_type.typname AS enumtype," +
                            "     pg_enum.enumlabel AS enumlabel" +
                            " FROM pg_type" +
                            " JOIN pg_enum" +
                            " ON pg_enum.enumtypid = pg_type.oid;");
            while (resultSet.next()) {
                allColorTypesList.add(resultSet.getString(2));
            }
            getColorTypesStmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
        return allColorTypesList;
    }


    /*
     * Initial clear for cat_colors_info table;
     */
    public void clearTable(String tableName) {
        try {
            connection.createStatement().execute("DELETE FROM " + tableName + "");
        } catch (SQLException e) {
            System.out.println("Something went wrong while trying to clear data from table");
            e.printStackTrace();
        }
    }

    public double calculateMeanValue(String columnName) throws Exception {
        System.out.println("\n\nStarting to calculate mean value for column: " + columnName);
        ArrayList<Integer> allValues = getAllColumnValues(columnName);
        double total = 0;
        double result = 0;
        if (allValues != null) {
            for (double value :
                    allValues) {
                total += value;
            }
            result = total / allValues.size();
            System.out.println("Count of values: " + allValues.size() + " Sum of values: " + total + " Mean: " + result);
            return result;
        } else {
            throw new Exception("This was an error while trying to calculate mean for column " + columnName);
        }
    }

    public double calculateMedian(String columnName) throws Exception {
        System.out.println("\n\nStarting to calculate median value for column: " + columnName);
        ArrayList<Integer> allValues = getAllColumnValues(columnName);
        if (allValues != null && allValues.size() > 0) {
            Collections.sort(allValues);
            System.out.println("Sorted values from column " + columnName + ": " + allValues);
            if (allValues.size() % 2 == 1) { //if not even then get middle element
                double result = allValues.get((allValues.size() / 2)-1);
                System.out.println("Median: " + result);
                return result;
            } else {  //if even then get two middle values and get their mean
                double tmpMedian1 = allValues.get(allValues.size() / 2);
                double tmpMedian2 = allValues.get((allValues.size() / 2) - 1);
                System.out.println("There count of values is  even, so the middle values are: " + tmpMedian2 + " " + tmpMedian1);
                double result = (tmpMedian1 + tmpMedian2) / 2;
                System.out.println("Median: " + result);
                return result;
            }
        } else {
            throw new Exception("This was an error while trying to calculate median for column " + columnName);
        }
    }

    public ArrayList<Integer> calculateMode(String columnName) {
        System.out.println("\n\nStarting to calculate mode for column: " + columnName);
        ArrayList<Integer> allValues = getAllColumnValues(columnName);
        ArrayList<Integer> results = new ArrayList<Integer>();
        Collections.sort(allValues); //sorts the collection of all values from the column
        System.out.println("Sorted values: " + allValues);
        System.out.println("Trying to get unique values...");
        Set<Integer> unique = new HashSet<Integer>(allValues); //getting all unnique values
        System.out.println("Unique values: " + unique);
        int maxFrequency = 0;
        System.out.println("Trying to find value with max frequency");

        //for each unique value
        for (Integer value : unique) {
            //calculate count
            int currentValueFrequency = Collections.frequency(allValues, value);
            if (currentValueFrequency > maxFrequency) { //if current value frequency is the most frequent
                maxFrequency = currentValueFrequency;
            }
        }
        System.out.println("Max frequency is: " + maxFrequency);


        //adding the ost frequent values to results list
        for (Integer value :
                unique) {
            if (Collections.frequency(allValues,value)==maxFrequency){
                results.add(value);
            }
        }
        System.out.println("Mode result: " + results);
        return results;
    }

    //returns all values from selected columns
    private ArrayList<Integer> getAllColumnValues(String columnName) {
        ArrayList<Integer> allValues = new ArrayList<Integer>();
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT " + columnName + "  FROM cats");
            while (resultSet.next()) {
                allValues.add(resultSet.getInt(1));
            }
            statement.close();
        } catch (SQLException e) {
            System.out.println("Something went wrong while trying to calculate mid-value for " + columnName + " in cats table;");
            e.printStackTrace();
            return null;
        }
        return allValues;
    }


    //inserts results to database
    public void insertStatsToDB(double tailMean, double tailMedian, ArrayList<Integer> tailMode, double whiskersMean, double whiskersMedian, ArrayList<Integer> whiskersMode) {
        try {
            java.sql.Array tailModeArray = connection.createArrayOf("integer",tailMode.toArray());
            java.sql.Array whiskersModeArray = connection.createArrayOf("integer",whiskersMode.toArray());
            DecimalFormat formatter = new DecimalFormat("##.00");

            PreparedStatement statement = connection.prepareStatement("INSERT INTO " +
                    "cats_stat(tail_length_mean,tail_length_median,tail_length_mode,whiskers_length_mean,whiskers_length_median,whiskers_length_mode) " +
                    "VALUES (?,?,?,?,?,?)");

            //setting to prepared statement prepared values
            statement.setDouble(1,Math.round(tailMean*100.0)/100.0);
            statement.setDouble(2,Math.round(tailMedian*100.0)/100.0);
            statement.setArray(3,tailModeArray);
            statement.setDouble(4,Math.round(whiskersMean*100.0)/100.0);
            statement.setDouble(5,Math.round(whiskersMedian*100.0)/100.0);
            statement.setArray(6,whiskersModeArray);
            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            System.out.println("Something went wrong while trying to insert stats to DB");
            e.printStackTrace();
        }
    }
}
